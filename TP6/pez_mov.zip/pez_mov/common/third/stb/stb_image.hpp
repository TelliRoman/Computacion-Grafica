#ifndef STB_IMAGE_H
#define STB_IMAGE_H

class stb_image {
public:
	stb_image();
private:
};

#endif

